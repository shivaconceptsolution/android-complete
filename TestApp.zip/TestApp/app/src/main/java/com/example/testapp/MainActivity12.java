package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity12 extends AppCompatActivity {

    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main12);
        txt = findViewById(R.id.txtresshared);
        @SuppressLint("WrongConstant")   SharedPreferences sharedpreferences = getSharedPreferences("pref", Context.MODE_APPEND);
        int r = sharedpreferences.getInt("rno",0);
        String s = sharedpreferences.getString("sname",null);
        txt.setText("rno is "+r+ "name is "+s);

    }
}