package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class SearchActivity11 extends AppCompatActivity {

    ListView list;
    SearchView editsearch;
    ArrayList animalNameList = new ArrayList();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search11);
        animalNameList.add("LION");
        animalNameList.add("MONKEY");
        animalNameList.add("ELEPHANT");
        animalNameList.add("CAT");
        animalNameList.add("TIGER");
        animalNameList.add("DOG");
        animalNameList.add("LEOPaRD");
        animalNameList.add("LIZARD");
        animalNameList.add("COW");
        animalNameList.add("COBRA");

        list = (ListView) findViewById(R.id.listview);
        ArrayAdapter aa = new ArrayAdapter(getApplicationContext(),
                android.R.layout.simple_list_item_1,animalNameList);
        list.setAdapter(aa);
        editsearch = (SearchView) findViewById(R.id.search);
        editsearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {

             /**    if(animalNameList.contains(s))
                 {
                     aa.getFilter().filter(s);
                 }
                 else
                 {
                     Toast.makeText(getApplicationContext(), "No Match found",Toast.LENGTH_LONG).show();
                 }*/
                 return  false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                aa.getFilter().filter(s);

                return false;
            }
        });

    }

}