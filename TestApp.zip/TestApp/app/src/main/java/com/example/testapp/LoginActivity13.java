package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.nio.channels.AsynchronousChannelGroup;

public class LoginActivity13 extends AppCompatActivity {

    EditText txtuname,txtupass;
    Button btnlogin;
    int status;
    String url = "https://shivaconceptdigital.com/api/login.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login13);
        txtuname = findViewById(R.id.txtuname1);
        txtupass = findViewById(R.id.txtupass1);
        btnlogin = findViewById(R.id.btnlogin);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = txtuname.getText().toString();
                String pass = txtupass.getText().toString();
                url+="?pwd="+pass+"&email="+email;
                new GetLogin().execute();
            }
        });

    }
    class GetLogin extends AsyncTask<Void ,Void, Void>
    {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog


        }
        @Override
        protected Void doInBackground(Void... voids) {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url,"POST");
            if (jsonStr != null) {

                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    status = jsonObj.getInt("status");

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result){

            super.onPostExecute(result);
            if(status==1)
            {
                Toast.makeText(getApplicationContext(),"Login Success and Activated",Toast.LENGTH_LONG).show();
            }
            else if(status==0)
            {
                Toast.makeText(getApplicationContext(),"Login Success and Not Activated",Toast.LENGTH_LONG).show();
            }
            else
            {
                Toast.makeText(getApplicationContext(),"Login Failed",Toast.LENGTH_LONG).show();

            }
        }
    }
}