package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FragmentExapleByCodeActivity extends AppCompatActivity {
    Button btnone;
    Button btntwo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_exaple_by_code);
        btnone = findViewById(R.id.btnfrg1);
        btntwo = findViewById(R.id.btnfrg2);
        btnone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frgcontainer,new FragmentFirst()).commit();
            }
        });

        btntwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getSupportFragmentManager().beginTransaction().replace(R.id.frgcontainer,new FragmentSecond()).commit();
            }
        });
    }
}