package com.example.testapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDb extends SQLiteOpenHelper {
    public static final String TABLE_NAME = "Student";

    // Table columns
    public static final String RNO = "rno";
    public static final String SNAME = "sname";
    public static final String BRANCH = "branch";
    public static final String FEES = "fees";
    static final int DB_VERSION = 1;
    // Database Information
    static final String DB_NAME = "test.db";
    private static final String CREATE_TABLE = "create table " + TABLE_NAME + "(" + RNO
            + " INTEGER PRIMARY KEY AUTOINCREMENT, " + SNAME + " TEXT NOT NULL, " + BRANCH + " TEXT ,"+ FEES + " INTEGER)";
    public  MyDb(Context ctx)
    {
        super(ctx,DB_NAME,null,DB_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
           db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("Drop table if exists "+TABLE_NAME);
    }
}
