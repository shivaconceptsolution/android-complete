package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity11 extends AppCompatActivity {

    EditText txtrno,txtname;
    Button btnshared;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main11);
        txtrno = findViewById(R.id.editrno);
        txtname = findViewById(R.id.editname);
        btnshared = findViewById(R.id.btnshared);
        final SharedPreferences sharedpreferences = getSharedPreferences("pref", Context.MODE_PRIVATE);
        btnshared.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.putInt("rno", Integer.parseInt(txtrno.getText().toString()));
                editor.putString("sname",txtname.getText().toString());
                editor.commit();
                Intent i = new Intent(getApplicationContext(),MainActivity12.class);
                startActivity(i);
            }
        });
    }
}