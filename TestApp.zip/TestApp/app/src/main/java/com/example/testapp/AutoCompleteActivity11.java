package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;
import android.widget.MultiAutoCompleteTextView;
import android.widget.Toast;

public class AutoCompleteActivity11 extends AppCompatActivity {

    AutoCompleteTextView act;
    ListView lstv;
    String course[] = {"JAVA","PHP","iOS","Android","Windows","LINUX","PYTHON","Angular"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auto_complete11);
        act = findViewById(R.id.atcmp);
        lstv = findViewById(R.id.lstauto);
        //mac = findViewById(R.id.multiautocomplete);
        ArrayAdapter obj = new ArrayAdapter(getApplicationContext(), android.R.layout.select_dialog_item,course);
        act.setThreshold(1);
        act.setAdapter(obj);
        act.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(),"Data is "+course[i],Toast.LENGTH_LONG).show();

            }
        });
   //     ArrayAdapter aa = new ArrayAdapter(getApplicationContext(),android.R.layout.select_dialog_item,course);
      //  mac.setThreshold(1);
       // mac.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        //mac.setAdapter(aa);
    }
}