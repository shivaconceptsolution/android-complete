package com.example.testapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.database.SQLException;

public class DBMANAGER {
    private MyDb dbHelper;

    private Context context;

    private SQLiteDatabase database;

    public DBMANAGER(Context c) {
        context = c;
    }
    public DBMANAGER open() throws SQLException {
        dbHelper = new MyDb(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }
    public void insert(String name, String branch, int fees) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(MyDb.SNAME, name);
        contentValue.put(MyDb.BRANCH, branch);
        contentValue.put(MyDb.FEES, fees);
        database.insert(MyDb.TABLE_NAME, null, contentValue);

    }
    public Cursor fetch() {

        Cursor cursor = database.rawQuery("Select * from "+ MyDb.TABLE_NAME,null);
        return cursor;
    }
    public int updateStudent(int rno, String name, String branch, int fees) {


        ContentValues contentValue = new ContentValues();
        contentValue.put(MyDb.SNAME, name);
        contentValue.put(MyDb.BRANCH, branch);
        contentValue.put(MyDb.FEES, fees);

        // updating row
        return database.update(MyDb.TABLE_NAME, contentValue, MyDb.RNO + " = ?",
                new String[] { String.valueOf(rno) });
    }
    public void deleteStudent(int rno) {

        database.delete(MyDb.TABLE_NAME, MyDb.RNO + " = ?",
                new String[] { String.valueOf(rno) });

    }
    public void closeConn()
    {
        database.close();
    }
}
