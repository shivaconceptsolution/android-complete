package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class SqliteActivity11 extends AppCompatActivity {
    Button btn,btnselect,btnupdate,btndelete;
    DBMANAGER obj;
    EditText txtrno,txtname,txtbranch,txtfees;
    ListView lst;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite11);
        obj = new DBMANAGER(this);
        obj.open();
        btn = findViewById(R.id.btnsqlite);
        txtrno = findViewById(R.id.strno);
        txtname = findViewById(R.id.stname);
        txtbranch = findViewById(R.id.stbranch);
        txtfees = findViewById(R.id.stfees);
        lst = findViewById(R.id.lstshowdata);
        btnselect = findViewById(R.id.btnsselect);
        btnupdate = findViewById(R.id.btnupate);
        btndelete = findViewById(R.id.btndelete);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.open();
                obj.insert(txtname.getText().toString(),txtbranch.getText().toString(),Integer.parseInt(txtfees.getText().toString()));
                Toast.makeText(getApplicationContext(),"Insert success" ,Toast.LENGTH_LONG).show();
                obj.closeConn();
                displaySelect();
            }
        });
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.open();
                obj.updateStudent(Integer.parseInt(txtrno.getText().toString()),txtname.getText().toString(),txtbranch.getText().toString(),Integer.parseInt(txtfees.getText().toString()));
                obj.closeConn();
                displaySelect();
            }
        });
        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.open();
               obj.deleteStudent(Integer.parseInt(txtrno.getText().toString()));
               obj.closeConn();
                displaySelect();
            }
        });
        btnselect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                displaySelect();
            }
        });


    }
    void displaySelect()
    {
        obj.open();

        Cursor c=obj.fetch();
        c.moveToFirst();
        String s[] = new String[c.getCount()];
        Toast.makeText(getApplicationContext(),""+c.getCount() ,Toast.LENGTH_LONG).show();
        for(int i=0;i<c.getCount();i++)
        {
            s[i] = c.getInt(0) + " "+c.getString(1) + " "+ c.getString(2)+ " "+ c.getInt(3);
            c.moveToNext();
        }
        ArrayAdapter aa = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_list_item_1,s);
        lst.setAdapter(aa);
        obj.closeConn();
    }
}