package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class WebViewActivity11 extends AppCompatActivity {
    WebView wbv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view11);
        wbv = findViewById(R.id.wbview);
        wbv.loadUrl("https://eroomrent.in/");
    }
}